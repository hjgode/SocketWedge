using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Net;

namespace SocketSend2
{
    public class pingutil
    {
        //[DllImport("iphlpapi.dll")]
        //internal static extern uint IcmpSendEcho2(IntPtr icmpHandle, IntPtr Event, IntPtr apcRoutine, IntPtr apcContext, uint ipAddress, IntPtr data, ushort dataSize, ref IPOptions options, IntPtr replyBuffer, uint replySize, uint timeout);
        //[DllImport("iphlpapi.dll")]
        //internal static extern IntPtr IcmpCreateFile();
        //[DllImport("iphlpapi")]
        //internal static extern bool IcmpCloseHandle(IntPtr handle);
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct ICMP_OPTIONS
        {
            public Byte Ttl;
            public Byte Tos;
            public Byte Flags;
            public Byte OptionsSize;
            public IntPtr OptionsData;
        };

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct ICMP_ECHO_REPLY
        {
            public int Address;
            public int Status;
            public int RoundTripTime;
            public Int16 DataSize;
            public Int16 Reserved;
            public IntPtr DataPtr;
            public ICMP_OPTIONS Options;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 250)]
            public String Data;
        }

        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern IntPtr IcmpCreateFile();
        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern bool IcmpCloseHandle(IntPtr handle);
        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern Int32 IcmpSendEcho(IntPtr icmpHandle, Int32 destinationAddress, String requestData, Int32 requestSize, ref ICMP_OPTIONS requestOptions, ref ICMP_ECHO_REPLY replyBuffer, Int32 replySize, Int32 timeout);

        private Form1 m_Form;

        public pingutil(Form1 theForm)
        {
            m_Form = theForm;
            t2 = new System.Threading.Thread(new System.Threading.ThreadStart(threadProc2));
            t2.Priority = System.Threading.ThreadPriority.BelowNormal;
            t2.Start();
        }

        private void threadProc2()
        {
            try
            { 
                myConfig mConfig=new myConfig();
                string sIP;
                bRunThread = true;
                m_safeToCloseGUI = false;
                updateGUI("--- Send Thread started ---");
                int iReply = 0;
                do
                {
                    sIP = mConfig.sIpAddr;
                    IPAddress ip = IPAddress.Parse(sIP);
                    iReply = Ping(ip);
                    if(iReply>0)
                        m_Form.Invoke(m_Form.myUpdateTextBox, new object[] { "connected" });
                    else
                        m_Form.Invoke(m_Form.myUpdateTextBox, new object[] { "not connected" });
                    System.Threading.Thread.Sleep(10000);

                } while (bRunThread);
            }
            catch(Exception ex){
                System.Diagnostics.Debug.WriteLine("Exception in threadProc2: " + ex.Message);
            }
        }

        public int Ping(IPAddress IP)
        {
            IntPtr ICMPHandle;
            Int32 iIP;
            String sData;
            ICMP_OPTIONS oICMPOptions = new ICMP_OPTIONS();
            ICMP_ECHO_REPLY ICMPReply = new ICMP_ECHO_REPLY();
            Int32 iReplies;

            ICMPHandle = IcmpCreateFile();
            iIP = BitConverter.ToInt32(IP.GetAddressBytes(), 0);
            sData = "x";
            oICMPOptions.Ttl = 255;

            iReplies = IcmpSendEcho(ICMPHandle, iIP,
                sData, sData.Length, ref oICMPOptions, ref ICMPReply,
                Marshal.SizeOf(ICMPReply), 30);

            IcmpCloseHandle(ICMPHandle);
            return iReplies;
        }
        //threading stuff
        private bool m_bRunThread = false;
        private System.Threading.Thread t2;
        private bool m_safeToCloseGUI = true;
        public bool _safeToCloseGUI
        {
            get { lock (this) { return m_safeToCloseGUI; } }
        }

        public bool bRunThread
        {

            get { lock (this) { return m_bRunThread; } }
            set { lock (this) { m_bRunThread = value; } }
        }
        public void AbortThread(string s)
        {
            if (s == string.Empty)
                s = "Thread abort requested!";
            t2.Abort(s);
        }
        private void updateGUI(string s)
        {
            if (bRunThread)
                m_Form.Invoke(m_Form.myUpdateTextBox, new object[] { s });
        }

    }
}
