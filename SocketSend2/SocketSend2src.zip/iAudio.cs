using System;
using System.Collections.Generic;
using System.Text;
using Intermec.Device.Audio;

namespace SocketSend2
{
    //using a class with try...catch we avoid possible problems with missing runtimes
    class iAudio
    {
        private Tone soundBad = new Tone(250, 100, Intermec.Device.Audio.Tone.VOLUME.CURRENT_CFG_VOL);
        private Tone soundGood = new Tone(1000, 50, Intermec.Device.Audio.Tone.VOLUME.CURRENT_CFG_VOL);
        public void playBad(){
            try
            {
                Tone soundBad = new Tone(250, 100, Intermec.Device.Audio.Tone.VOLUME.CURRENT_CFG_VOL);
                soundBad.Play();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Exception in playBad " + ex.Message + ". \r\nRUNTIME missing?");
            }
        }
        public void playGood()
        {
            try
            {
                Tone soundGood = new Tone(1000, 50, Intermec.Device.Audio.Tone.VOLUME.CURRENT_CFG_VOL);
                soundGood.Play();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Exception in playGood " + ex.Message + ". \r\nRUNTIME missing?");
            }
        }
    }
}
